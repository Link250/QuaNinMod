using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace NinMod.Items.TestItems
{
	public class TestSword : ModItem
	{
		public override void SetDefaults()
		{
			
			item.name = "sosos";
			item.damage = 132;
			item.melee = true;
			item.width = 40;
			item.height = 40;
			item.toolTip = "This saas";
			item.useTime = 20;
			item.useAnimation = 20;
			item.useStyle = 1;
			item.knockBack = 18;
			item.value = 10000;
			item.rare = 2;
			item.useSound = 1;
			item.autoReuse = true;
			
		}
	
		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddTile(18);
			recipe.SetResult(this);
			recipe.AddIngredient(ItemID.DirtBlock, 1);
			recipe.AddRecipe();
		}
		
		public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
		{
			target.AddBuff(24, 600);
			target.AddBuff(39, 600);
			target.AddBuff(44, 600);
			target.AddBuff(153, 600);
		}
	}
}